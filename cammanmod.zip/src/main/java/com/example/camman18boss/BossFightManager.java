package com.example.camman18boss;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.GiantEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;

public final class BossFightManager {
    private static final String BOSS_NAME = "CAMMAN18";
    private static final Box WORLD_SCAN_BOX = new Box(-30_000_000, -128, -30_000_000, 30_000_000, 512, 30_000_000);

    private static final Set<UUID> playersWhoAlreadySpawnedBossThisRide = new HashSet<>();
    private static final Map<UUID, Integer> bossAttackCooldowns = new HashMap<>();

    private BossFightManager() {
    }

    public static void tick(MinecraftServer server) {
        for (ServerWorld world : server.getWorlds()) {
            handleRideTriggers(world);
            tickBosses(world);
        }
    }

    private static void handleRideTriggers(ServerWorld world) {
        for (PlayerEntity player : world.getPlayers()) {
            Entity vehicle = player.getVehicle();

            if (vehicle instanceof AbstractMinecartEntity) {
                if (playersWhoAlreadySpawnedBossThisRide.add(player.getUuid())) {
                    spawnBoss(world, player);
                }
            } else {
                playersWhoAlreadySpawnedBossThisRide.remove(player.getUuid());
            }
        }
    }

    private static void spawnBoss(ServerWorld world, PlayerEntity player) {
        GiantEntity boss = EntityType.GIANT.create(world);
        if (boss == null) {
            return;
        }

        boss.refreshPositionAndAngles(player.getX() + 2.0D, player.getY(), player.getZ() + 2.0D, world.getRandom().nextFloat() * 360.0F, 0.0F);
        boss.setCustomName(Text.literal(BOSS_NAME));
        boss.setCustomNameVisible(true);
        boss.setPersistent();

        if (boss.getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MAX_HEALTH) != null) {
            boss.getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(250.0D);
        }
        if (boss.getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.GENERIC_ATTACK_DAMAGE) != null) {
            boss.getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(18.0D);
        }
        if (boss.getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MOVEMENT_SPEED) != null) {
            boss.getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.30D);
        }

        boss.setHealth(boss.getMaxHealth());
        world.spawnEntity(boss);

        player.sendMessage(Text.translatable("message.camman18boss.spawn"), false);
        world.playSound(
                null,
                player.getBlockPos(),
                SoundEvents.ENTITY_GHAST_SCREAM,
                SoundCategory.HOSTILE,
                3.0F,
                0.65F
        );
    }

    private static void tickBosses(ServerWorld world) {
        for (GiantEntity boss : world.getEntitiesByClass(GiantEntity.class, WORLD_SCAN_BOX, BossFightManager::isBoss)) {
            PlayerEntity target = findClosestPlayer(world, boss);

            if (target == null) {
                continue;
            }

            boss.getNavigation().startMovingTo(target, 1.15D);
            boss.getLookControl().lookAt(target, 30.0F, 30.0F);

            UUID bossId = boss.getUuid();
            int cooldown = bossAttackCooldowns.getOrDefault(bossId, 0);
            if (cooldown > 0) {
                bossAttackCooldowns.put(bossId, cooldown - 1);
                continue;
            }

            double distanceSquared = boss.squaredDistanceTo(target);

            if (distanceSquared <= 9.0D) {
                target.damage(world.getDamageSources().mobAttack(boss), 10.0F);
                target.takeKnockback(0.6D, boss.getX() - target.getX(), boss.getZ() - target.getZ());
                target.sendMessage(Text.translatable("message.camman18boss.attack.close"), true);
                bossAttackCooldowns.put(bossId, 20);
            } else if (distanceSquared <= 400.0D) {
                world.playSound(
                        null,
                        target.getBlockPos(),
                        SoundEvents.ENTITY_WARDEN_SONIC_BOOM,
                        SoundCategory.HOSTILE,
                        4.0F,
                        1.0F
                );
                target.damage(world.getDamageSources().mobAttack(boss), 8.0F);
                target.takeKnockback(1.2D, boss.getX() - target.getX(), boss.getZ() - target.getZ());
                target.sendMessage(Text.translatable("message.camman18boss.attack.far"), true);
                bossAttackCooldowns.put(bossId, 80);
            }
        }
    }

    private static PlayerEntity findClosestPlayer(ServerWorld world, GiantEntity boss) {
        PlayerEntity closest = null;
        double closestDistance = Double.MAX_VALUE;

        for (PlayerEntity player : world.getPlayers()) {
            if (player.isSpectator() || player.isCreative()) {
                continue;
            }

            double distance = boss.squaredDistanceTo(player);
            if (distance < closestDistance) {
                closestDistance = distance;
                closest = player;
            }
        }

        return closest;
    }

    public static boolean isBoss(GiantEntity entity) {
        return entity.isAlive()
                && entity.hasCustomName()
                && entity.getCustomName() != null
                && BOSS_NAME.equals(entity.getCustomName().getString());
    }

    public static boolean canDamageBoss(Entity attacker) {
        if (!(attacker instanceof PlayerEntity player)) {
            return false;
        }

        ItemStack stack = player.getMainHandStack();
        return isBirchWood(stack);
    }

    private static boolean isBirchWood(ItemStack stack) {
        return stack.isOf(Items.BIRCH_LOG)
                || stack.isOf(Items.STRIPPED_BIRCH_LOG)
                || stack.isOf(Items.BIRCH_WOOD)
                || stack.isOf(Items.STRIPPED_BIRCH_WOOD)
                || stack.isOf(Items.BIRCH_PLANKS)
                || stack.isOf(Items.BIRCH_SLAB)
                || stack.isOf(Items.BIRCH_STAIRS)
                || stack.isOf(Items.BIRCH_FENCE)
                || stack.isOf(Items.BIRCH_FENCE_GATE)
                || stack.isOf(Items.BIRCH_DOOR)
                || stack.isOf(Items.BIRCH_TRAPDOOR)
                || stack.isOf(Items.BIRCH_BUTTON)
                || stack.isOf(Items.BIRCH_PRESSURE_PLATE)
                || stack.isOf(Items.BIRCH_SIGN)
                || stack.isOf(Items.BIRCH_BOAT)
                || stack.isOf(Items.BIRCH_CHEST_BOAT);
    }
}
