package com.example.camman18boss;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

public class CammanBossMod implements ModInitializer {
    public static final String MOD_ID = "camman18boss";

    @Override
    public void onInitialize() {
        ServerTickEvents.END_SERVER_TICK.register(BossFightManager::tick);
    }
}
