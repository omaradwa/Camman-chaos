package com.example.camman18boss.mixin;

import com.example.camman18boss.BossFightManager;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.GiantEntity;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void camman18boss$onlyBirchCanHurtTheBoss(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;

        if (self instanceof GiantEntity giant && BossFightManager.isBoss(giant)) {
            if (!BossFightManager.canDamageBoss(source.getAttacker())) {
                cir.setReturnValue(false);
            }
        }
    }
}
